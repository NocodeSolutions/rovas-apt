"""Core modules for Rovas Eszkozok."""
