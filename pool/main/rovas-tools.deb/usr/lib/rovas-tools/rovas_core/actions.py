from __future__ import annotations

from dataclasses import dataclass
import os
from pathlib import Path
import shutil
import subprocess

from rovas_core.backup import save_backup
from rovas_core.detect_system import detect_session
from rovas_core.logging import append_log
from rovas_core.report import write_support_report
from rovas_core.status import probe_system


POLICY_FILES = [
    "/etc/chromium/policies/managed/rovas-extension-policy.json",
    "/etc/opt/chrome/policies/managed/rovas-extension-policy.json",
    "/etc/brave/policies/managed/rovas-extension-policy.json",
]


@dataclass(frozen=True)
class ActionResult:
    code: int
    success_key: str
    failure_key: str
    open_browser: bool = False


def has(command: str) -> bool:
    return shutil.which(command) is not None


def current_user() -> str:
    result = subprocess.run(["id", "-un"], text=True, capture_output=True)
    return result.stdout.strip() or "root"


def privileged(command: list[str]) -> int:
    pkexec = shutil.which("pkexec")
    if not pkexec:
        return 127
    return subprocess.call([pkexec, *command])


def apply_user_keyboard_session() -> int:
    rovas_mode = shutil.which("rovas-mode")
    if not rovas_mode:
        return 127
    return subprocess.call([rovas_mode, "apply-user-session"])


def current_mode_value() -> str:
    result = subprocess.run(["rovas-mode", "status"], text=True, capture_output=True)
    return result.stdout.strip() if result.returncode == 0 and result.stdout.strip() else "unknown"


def write_rovas_config(name: str, content: str) -> None:
    config_dir = Path.home() / ".config" / "rovas-tools"
    config_dir.mkdir(parents=True, exist_ok=True)
    (config_dir / name).write_text(content, encoding="utf-8")


def stop_chromium_browsers() -> None:
    user = current_user()
    for name in [
        "chrome",
        "google-chrome",
        "google-chrome-stable",
        "chromium",
        "chromium-browser",
        "brave",
        "brave-browser",
    ]:
        subprocess.call(["pkill", "-u", user, "-x", name], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def mark_first_run_complete() -> None:
    write_rovas_config("first-run-complete", "1\n")


def save_current_backup(action: str) -> None:
    try:
        probes = probe_system()
        session = detect_session()
        save_backup(
            home=Path.home(),
            created_by="rovas-tools",
            desktop=session.desktop,
            session=session.session_type,
            previous_mode=current_mode_value(),
            previous_locale=os.environ.get("LANG", ""),
            previous_font=f"{probes.font_family} {probes.font_size}".strip(),
            previous_monospace_font="",
            previous_wallpaper=probes.wallpaper_mode,
            previous_keyboard_layout=probes.keyboard_config,
            previous_keyboard_options="",
            browser_policies_created=tuple(path for path in POLICY_FILES if os.path.exists(path)),
        )
        append_log(Path.home(), "INFO", f"backup saved before {action}")
    except Exception as exc:
        append_log(Path.home(), "WARN", f"backup failed before {action}: {exc}")


def restore_rovas_settings() -> int:
    save_current_backup("restore_rovas_settings")
    for command in (
        ["rovas-font-settings", "restore"],
        ["rovas-apply-wallpaper", "--restore"],
    ):
        subprocess.call(command)
    code = privileged(["/usr/bin/rovas-mode", "set", "hu", "--logout-user", current_user()])
    if code == 0:
        if has("rovas-browser-policy"):
            code = privileged(["/usr/bin/rovas-browser-policy", "remove"])
        else:
            code = privileged(["/usr/bin/rm", "-f", *POLICY_FILES])
    if code == 0:
        code = privileged(["/usr/bin/rovas-refresh-desktop-entries", "--restore"])
    append_log(Path.home(), "INFO" if code == 0 else "ERROR", f"restore_rovas_settings finished with {code}")
    return code


def run_action(action: str, *args: str) -> ActionResult:
    if action == "enable_rovas":
        save_current_backup(action)
        code = privileged(["/usr/bin/rovas-mode", "set", "rovas", "--logout-user", current_user()])
        return ActionResult(code, "mode_rovas_set", "mode_rovas_failed")
    if action == "enable_hungarian":
        save_current_backup(action)
        code = privileged(["/usr/bin/rovas-mode", "set", "hu", "--logout-user", current_user()])
        return ActionResult(code, "mode_hu_set", "mode_hu_failed")
    if action == "apply_keyboard":
        save_current_backup(action)
        code = privileged(["/usr/bin/rovas-bootstrap"])
        if code == 0:
            code = apply_user_keyboard_session()
        return ActionResult(code, "keyboard_applied", "keyboard_failed")
    if action == "apply_font":
        if len(args) != 2:
            return ActionResult(2, "font_failed", "font_failed")
        save_current_backup(action)
        code = subprocess.call(["/usr/bin/rovas-font-settings", "apply", args[0], args[1]])
        return ActionResult(code, "font_applied", "font_failed")
    if action == "repair_settings":
        save_current_backup(action)
        code = privileged(["/usr/bin/rovas-bootstrap"])
        if code == 0:
            code = privileged(["/usr/bin/rovas-mode", "refresh"])
        if code == 0:
            code = subprocess.call(["rovas-apply-current-settings"])
        return ActionResult(code, "repair_done", "repair_failed")
    if action == "apply_current_settings":
        save_current_backup(action)
        code = subprocess.call(["rovas-apply-current-settings"])
        return ActionResult(code, "current_settings_applied", "current_settings_failed")
    if action == "first_run_setup":
        save_current_backup(action)
        code = privileged(["/usr/bin/rovas-bootstrap"])
        if code == 0:
            code = apply_user_keyboard_session()
        if code == 0:
            code = subprocess.call(["rovas-apply-current-settings"])
        if code == 0 and has("rovas-browser-policy"):
            code = privileged(["/usr/bin/rovas-browser-policy", "install"])
            if code == 0:
                stop_chromium_browsers()
        if code == 0:
            mark_first_run_complete()
        return ActionResult(
            code,
            "first_run_complete",
            "first_run_failed",
            open_browser=(code == 0 and has("rovas-browser")),
        )
    if action == "refresh_menus":
        save_current_backup(action)
        if current_mode_value() == "hu":
            code = privileged(["/usr/bin/rovas-refresh-desktop-entries", "--restore"])
        else:
            code = privileged(["/usr/bin/rovas-mode", "refresh"])
        return ActionResult(code, "menus_refreshed", "menus_refresh_failed")
    if action == "set_wallpaper_mode":
        if len(args) != 1 or args[0] not in {"rovas-default", "keep-system"}:
            return ActionResult(2, "wallpaper_failed", "wallpaper_failed")
        save_current_backup(action)
        write_rovas_config("wallpaper.conf", f"mode={args[0]}\n")
        env = os.environ.copy()
        env["ROVAS_WALLPAPER_FORCE"] = "1"
        code = subprocess.call(["rovas-apply-wallpaper"], env=env)
        return ActionResult(code, "wallpaper_applied", "wallpaper_failed")
    if action == "export_report":
        write_support_report()
        return ActionResult(0, "report_exported", "report_failed")
    if action == "restore_rovas_settings":
        code = restore_rovas_settings()
        return ActionResult(code, "restore_done", "restore_failed")
    if action == "complete_first_run":
        mark_first_run_complete()
        return ActionResult(0, "first_run_complete", "first_run_failed")
    if action == "install_browser_tools":
        save_current_backup(action)
        command = (
            ["/usr/bin/rovas-browser-policy", "install"]
            if has("rovas-browser-policy")
            else ["/usr/bin/apt-get", "install", "-y", "rovas-browser-chromium"]
        )
        code = privileged(command)
        if code == 0:
            stop_chromium_browsers()
        return ActionResult(
            code,
            "browser_policy_installed",
            "browser_policy_install_failed",
            open_browser=(code == 0 and has("rovas-browser")),
        )
    if action == "remove_browser_policy":
        save_current_backup(action)
        command = (
            ["/usr/bin/rovas-browser-policy", "remove"]
            if has("rovas-browser-policy")
            else ["/usr/bin/rm", "-f", *POLICY_FILES]
        )
        code = privileged(command)
        return ActionResult(code, "browser_policy_removed", "browser_policy_remove_failed")
    if action == "refresh_translations":
        save_current_backup(action)
        code = privileged(["/usr/bin/rovas-mode", "refresh"])
        return ActionResult(code, "translations_refreshed", "translations_refresh_failed")
    return ActionResult(2, "unsupported_action", "unsupported_action")
