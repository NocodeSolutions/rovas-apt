from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path
import subprocess


DEFAULT_COMPONENT_DIR = Path("/usr/share/rovas/components")


@dataclass(frozen=True)
class ComponentManifest:
    component: str
    package: str
    version: str
    required: bool
    capabilities: tuple[str, ...]


def load_component_manifests(path: Path = DEFAULT_COMPONENT_DIR) -> list[ComponentManifest]:
    manifests: list[ComponentManifest] = []
    if not path.exists():
        return manifests
    for manifest_path in sorted(path.glob("*.json")):
        data = json.loads(manifest_path.read_text(encoding="utf-8"))
        manifests.append(
            ComponentManifest(
                component=str(data["component"]),
                package=str(data["package"]),
                version=str(data["version"]),
                required=bool(data["required"]),
                capabilities=tuple(str(value) for value in data.get("capabilities", [])),
            )
        )
    return manifests


def package_installed(package: str) -> bool:
    result = subprocess.run(
        ["dpkg-query", "-W", "-f=${Status}", package],
        text=True,
        capture_output=True,
    )
    return result.returncode == 0 and result.stdout.strip() == "install ok installed"
