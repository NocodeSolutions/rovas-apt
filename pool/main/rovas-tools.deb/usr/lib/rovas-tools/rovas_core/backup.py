from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
import json
from pathlib import Path


BACKUP_NAME = "backup.json"
BACKUP_VERSION = "1.0.0"


@dataclass(frozen=True)
class BackupSnapshot:
    created_by: str
    version: str
    created_at: str
    desktop: str
    session: str
    previous_mode: str
    previous_locale: str
    previous_font: str
    previous_monospace_font: str
    previous_wallpaper: str
    previous_keyboard_layout: str
    previous_keyboard_options: str
    browser_policies_created: tuple[str, ...] = field(default_factory=tuple)


def config_dir(home: Path | None = None) -> Path:
    return (home or Path.home()) / ".config" / "rovas-tools"


def backup_path(home: Path | None = None) -> Path:
    return config_dir(home) / BACKUP_NAME


def _now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def save_backup(
    *,
    home: Path | None = None,
    created_by: str = "rovas-tools",
    desktop: str,
    session: str,
    previous_mode: str = "",
    previous_locale: str,
    previous_font: str,
    previous_monospace_font: str = "",
    previous_wallpaper: str,
    previous_keyboard_layout: str,
    previous_keyboard_options: str = "",
    browser_policies_created: tuple[str, ...] = (),
) -> Path:
    snapshot = BackupSnapshot(
        created_by=created_by,
        version=BACKUP_VERSION,
        created_at=_now(),
        desktop=desktop,
        session=session,
        previous_mode=previous_mode,
        previous_locale=previous_locale,
        previous_font=previous_font,
        previous_monospace_font=previous_monospace_font,
        previous_wallpaper=previous_wallpaper,
        previous_keyboard_layout=previous_keyboard_layout,
        previous_keyboard_options=previous_keyboard_options,
        browser_policies_created=tuple(browser_policies_created),
    )
    payload = asdict(snapshot)
    payload["browser_policies_created"] = list(snapshot.browser_policies_created)
    path = backup_path(home)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return path


def read_backup(home: Path | None = None) -> BackupSnapshot | None:
    path = backup_path(home)
    if not path.exists():
        return None
    data = json.loads(path.read_text(encoding="utf-8"))
    return BackupSnapshot(
        created_by=str(data.get("created_by", "rovas-tools")),
        version=str(data.get("version", BACKUP_VERSION)),
        created_at=str(data.get("created_at", "")),
        desktop=str(data.get("desktop", "unknown")),
        session=str(data.get("session", "unknown")),
        previous_mode=str(data.get("previous_mode", "")),
        previous_locale=str(data.get("previous_locale", "")),
        previous_font=str(data.get("previous_font", "")),
        previous_monospace_font=str(data.get("previous_monospace_font", "")),
        previous_wallpaper=str(data.get("previous_wallpaper", "")),
        previous_keyboard_layout=str(data.get("previous_keyboard_layout", "")),
        previous_keyboard_options=str(data.get("previous_keyboard_options", "")),
        browser_policies_created=tuple(str(value) for value in data.get("browser_policies_created", [])),
    )


def restore_plan(snapshot: BackupSnapshot | None) -> list[str]:
    if snapshot is None:
        return ["Nincs mentett visszaállítási pont."]
    steps = [
        "Magyar latin mód visszaállítása",
        "Billentyűzetkiosztás visszaállítása",
    ]
    if snapshot.previous_font:
        steps.append(f"Betűkészlet visszaállítása: {snapshot.previous_font}")
    if snapshot.previous_wallpaper:
        steps.append("Háttérkép visszaállítása")
    if snapshot.browser_policies_created:
        steps.append("Chrome/Chromium bővítményszabály törlése")
    steps.append("Menüfordítások visszaállítása, ha Rovás módban módosultak")
    return steps
