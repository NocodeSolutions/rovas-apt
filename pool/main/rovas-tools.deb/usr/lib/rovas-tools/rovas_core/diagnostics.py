from __future__ import annotations


SUPPORTED_DESKTOPS = ("Cinnamon", "Xfce", "MATE", "GNOME")


def compatibility_rows(
    *,
    os_pretty_name: str,
    package_family: str,
    desktop: str,
    session_type: str,
    chromium_names: tuple[str, ...],
    firefox_detected: bool,
) -> list[tuple[str, str]]:
    supported = "igen" if package_family == "apt" and desktop in SUPPORTED_DESKTOPS else "részleges"
    wayland = "részleges" if session_type.lower() == "wayland" else "nem érintett"
    browser = f"{', '.join(chromium_names)} felismerve" if chromium_names else "nincs Chromium böngésző felismerve"
    firefox = "Firefox felismerve; bővítménycsomag később" if firefox_detected else "Firefox nincs felismerve"
    return [
        ("Támogatott rendszer", supported),
        ("Rendszer", os_pretty_name),
        ("Asztali környezet", desktop),
        ("Munkamenet", session_type),
        ("Wayland támogatás", wayland),
        ("Böngésző", browser),
        ("Firefox", firefox),
    ]


def dry_run_preview(
    *,
    mode: str,
    desktop: str,
    chromium_names: tuple[str, ...],
    browser_policy_count: int,
) -> list[str]:
    steps = [
        "A következő műveletek futnának:",
        "Rovás locale ellenőrzése",
        "Rovás betűkészlet ellenőrzése",
        "Billentyűzetkiosztás telepítése",
        f"{desktop} betűkészlet beállítása",
        "Háttérkép beállítás ellenőrzése",
    ]
    if chromium_names or browser_policy_count:
        steps.append("Chromium házirend frissítése")
    if mode != "rovas":
        steps.append("Rovás mód bekapcsolása kijelentkezés után")
    return steps


def permission_rows(*, can_write_system: bool, can_write_user: bool, pkexec_available: bool) -> list[tuple[str, str]]:
    system = "elérhető" if can_write_system else "engedélyt kér" if pkexec_available else "nem elérhető"
    user = "elérhető" if can_write_user else "nem elérhető"
    pkexec = "elérhető" if pkexec_available else "nem elérhető"
    return [
        ("Rendszerszintű fájlok írása", system),
        ("Felhasználói beállítások módosítása", user),
        ("Jogosultságkérés", pkexec),
    ]


def adapter_rows(desktop: str) -> list[tuple[str, str]]:
    active = desktop if desktop in SUPPORTED_DESKTOPS else "Általános"
    return [
        ("Aktív adapter", active),
        ("Elérhető adapterek", ", ".join(SUPPORTED_DESKTOPS)),
    ]
