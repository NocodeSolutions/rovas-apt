from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


FONT_SIZE_MIN = 8
FONT_SIZE_MAX = 24
DEFAULT_FONT = "Old Hungarian"
DEFAULT_WALLPAPER_MODE = "rovas-default"
VALID_WALLPAPER_MODES = {"rovas-default", "keep-system"}
CONFIG_DIR = ".config/rovas-tools"


@dataclass(frozen=True)
class RovasSettings:
    font_family: str
    font_size: int
    wallpaper_mode: str
    first_run_complete: bool


def config_root(home: Path) -> Path:
    return home / CONFIG_DIR


def parse_key_value_file(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    if not path.exists():
        return values
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line or line.lstrip().startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        values[key.strip()] = value.strip()
    return values


def read_settings(home: Path | None = None) -> RovasSettings:
    home = home or Path.home()
    root = config_root(home)
    font = parse_key_value_file(root / "font.conf")
    wallpaper = parse_key_value_file(root / "wallpaper.conf")
    size_text = font.get("size", str(FONT_SIZE_MIN))
    try:
        size = int(size_text)
    except ValueError:
        size = FONT_SIZE_MIN
    if size < FONT_SIZE_MIN or size > FONT_SIZE_MAX:
        size = FONT_SIZE_MIN
    wallpaper_mode = wallpaper.get("mode", DEFAULT_WALLPAPER_MODE)
    if wallpaper_mode not in VALID_WALLPAPER_MODES:
        wallpaper_mode = DEFAULT_WALLPAPER_MODE
    return RovasSettings(
        font_family=font.get("font", DEFAULT_FONT) or DEFAULT_FONT,
        font_size=size,
        wallpaper_mode=wallpaper_mode,
        first_run_complete=(root / "first-run-complete").exists(),
    )


def write_font_settings(home: Path, font_family: str, font_size: int) -> None:
    if font_size < FONT_SIZE_MIN or font_size > FONT_SIZE_MAX:
        raise ValueError(f"font size must be {FONT_SIZE_MIN}-{FONT_SIZE_MAX}")
    root = config_root(home)
    root.mkdir(parents=True, exist_ok=True)
    (root / "font.conf").write_text(f"font={font_family}\nsize={font_size}\n", encoding="utf-8")


def write_wallpaper_mode(home: Path, mode: str) -> None:
    if mode not in VALID_WALLPAPER_MODES:
        raise ValueError(f"unsupported wallpaper mode: {mode}")
    root = config_root(home)
    root.mkdir(parents=True, exist_ok=True)
    (root / "wallpaper.conf").write_text(f"mode={mode}\n", encoding="utf-8")


def mark_first_run_complete(home: Path) -> None:
    root = config_root(home)
    root.mkdir(parents=True, exist_ok=True)
    (root / "first-run-complete").write_text("1\n", encoding="utf-8")
