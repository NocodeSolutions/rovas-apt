from __future__ import annotations

from dataclasses import dataclass
import glob
import os
from pathlib import Path
import shutil
import subprocess

try:
    from .settings import read_settings
except ImportError:
    from settings import read_settings  # type: ignore

try:
    from .components import load_component_manifests, package_installed
except ImportError:  # pragma: no cover - fallback for direct module loading
    from components import load_component_manifests, package_installed  # type: ignore


@dataclass(frozen=True)
class StatusItem:
    key: str
    label_hu: str
    detail_hu: str
    severity: str
    kind: str = "required"


@dataclass(frozen=True)
class ComponentStatusRow:
    component: str
    package: str
    required: bool
    package_installed: bool
    files_healthy: bool | None
    user_setting_active: bool | None


@dataclass(frozen=True)
class ProbeResults:
    rovas_locale: bool
    old_hungarian_font: bool
    rovas_keyboard: bool
    browser_policy_count: int
    browser_commands: tuple[str, ...]
    catalog_count: int
    mode: str = "unknown"
    font_family: str = "Old Hungarian"
    font_size: int = 8
    wallpaper_mode: str = "rovas-default"
    keyboard_config: str = ""
    installed_packages: tuple[str, ...] = ()


def _run(command: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(command, text=True, capture_output=True)


def _read_text(path: Path) -> str:
    if not path.exists():
        return ""
    return path.read_text(encoding="utf-8", errors="replace").strip()


def probe_system() -> ProbeResults:
    locale_result = _run(["locale", "-a"])
    rovas_locale = any("rovas" in line.lower() for line in locale_result.stdout.splitlines())
    font_result = _run(["fc-match", "Noto Sans Old Hungarian"])
    old_hungarian_font = bool(font_result.stdout.strip())
    rovas_keyboard = os.path.exists("/etc/default/keyboard.d/99-rovas-keyboard")
    policy_files = [
        "/etc/chromium/policies/managed/rovas-extension-policy.json",
        "/etc/opt/chrome/policies/managed/rovas-extension-policy.json",
        "/etc/brave/policies/managed/rovas-extension-policy.json",
    ]
    browser_names = [
        "google-chrome-stable",
        "google-chrome",
        "chromium-browser",
        "chromium",
        "brave-browser",
        "firefox",
    ]
    mode_result = _run(["rovas-mode", "status"])
    mode = mode_result.stdout.strip() if mode_result.returncode == 0 and mode_result.stdout.strip() else "unknown"
    settings = read_settings(Path.home())
    installed_packages = tuple(
        manifest.package
        for manifest in load_component_manifests()
        if package_installed(manifest.package)
    )
    return ProbeResults(
        rovas_locale=rovas_locale,
        old_hungarian_font=old_hungarian_font,
        rovas_keyboard=rovas_keyboard,
        browser_policy_count=sum(1 for path in policy_files if os.path.exists(path)),
        browser_commands=tuple(name for name in browser_names if shutil.which(name)),
        catalog_count=len(glob.glob("/usr/share/locale/hu_HU@rovas/LC_MESSAGES/*.mo")),
        mode=mode,
        font_family=settings.font_family,
        font_size=settings.font_size,
        wallpaper_mode=settings.wallpaper_mode,
        keyboard_config=_read_text(Path("/etc/default/keyboard")),
        installed_packages=installed_packages,
    )


def component_status_rows(probes: ProbeResults) -> list[ComponentStatusRow]:
    rovas_active = probes.mode == "rovas"
    files_healthy = {
        "fonts": probes.old_hungarian_font,
        "keyboard": probes.rovas_keyboard,
        "locale-hu": probes.rovas_locale,
        "l10n-hu": probes.catalog_count > 0,
        "wallpapers": None,
        "browser-chromium": probes.browser_policy_count > 0,
    }
    user_setting_active = {
        "fonts": rovas_active,
        "keyboard": rovas_active,
        "locale-hu": rovas_active,
        "l10n-hu": None,
        "wallpapers": probes.wallpaper_mode == "rovas-default",
        "browser-chromium": None,
    }
    rows: list[ComponentStatusRow] = []
    for manifest in load_component_manifests():
        rows.append(
            ComponentStatusRow(
                component=manifest.component,
                package=manifest.package,
                required=manifest.required,
                package_installed=manifest.package in probes.installed_packages,
                files_healthy=files_healthy.get(manifest.component),
                user_setting_active=user_setting_active.get(manifest.component),
            )
        )
    return rows


def collect_status(probes: ProbeResults) -> list[StatusItem]:
    chromium = chromium_browser_commands(probes)
    chromium_detail = (
        f"{', '.join(chromium)} felismerve; {probes.browser_policy_count} házirend fájl"
        if chromium
        else f"nincs böngésző felismerve; {probes.browser_policy_count} házirend fájl"
    )
    items = [
        StatusItem(
            "locale",
            "Rovás locale",
            "elérhető" if probes.rovas_locale else "hiányzik",
            "ok" if probes.rovas_locale else "error",
        ),
        StatusItem(
            "font",
            "Rovás betűkészlet",
            "elérhető" if probes.old_hungarian_font else "hiányzik",
            "ok" if probes.old_hungarian_font else "error",
        ),
        StatusItem(
            "keyboard",
            "Rovás billentyűzet",
            "elérhető" if probes.rovas_keyboard else "hiányzik",
            "ok" if probes.rovas_keyboard else "warning",
        ),
        StatusItem(
            "browser_policy",
            "Chrome/Chromium bővítmény",
            chromium_detail,
            "ok" if probes.browser_policy_count else "warning",
        ),
        StatusItem(
            "translations",
            "Fordítások",
            f"{probes.catalog_count} katalógus",
            "ok" if probes.catalog_count else "warning",
        ),
    ]
    if "firefox" in probes.browser_commands:
        items.append(
            StatusItem(
                "firefox",
                "Opcionális",
                "Firefox felismerve; a bővítménycsomag később lesz elérhető",
                "warning",
                "optional",
            )
        )
    return items


def needs_user_intervention(items: list[StatusItem]) -> bool:
    return any(item.kind != "optional" and item.severity in {"warning", "error"} for item in items)


def has_optional_tasks(items: list[StatusItem]) -> bool:
    return any(item.kind == "optional" and item.severity in {"warning", "error"} for item in items)


def chromium_browser_commands(probes: ProbeResults) -> list[str]:
    return [name for name in probes.browser_commands if name != "firefox"]


def browser_detection_lines(probes: ProbeResults) -> str:
    chromium = chromium_browser_commands(probes)
    return "\n".join(
        [
            f"Chrome/Chromium: {', '.join(chromium) if chromium else 'nincs'}",
            f"Firefox: {'felismerve' if 'firefox' in probes.browser_commands else 'nincs'}",
            f"Böngésző házirend fájlok: {probes.browser_policy_count}",
        ]
    )


def detailed_status_lines(probes: ProbeResults) -> str:
    browsers = ", ".join(probes.browser_commands) if probes.browser_commands else "nincs"
    keyboard = probes.keyboard_config.replace("\n", "; ") if probes.keyboard_config else "nincs adat"
    return "\n".join(
        [
            f"Mód: {probes.mode}",
            f"Rovás locale: {'elérhető' if probes.rovas_locale else 'hiányzik'}",
            f"Betűkészlet: {probes.font_family} {probes.font_size}",
            f"Háttérkép: {probes.wallpaper_mode}",
            f"Billentyűzet: {keyboard}",
            f"Böngésző házirend fájlok: {probes.browser_policy_count}",
            f"Böngészők: {browsers}",
            f"Fordítások: {probes.catalog_count} katalógus",
        ]
    )
