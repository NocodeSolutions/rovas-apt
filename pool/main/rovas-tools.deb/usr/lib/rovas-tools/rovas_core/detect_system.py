from __future__ import annotations

from dataclasses import dataclass
import os
from pathlib import Path
import shutil


@dataclass(frozen=True)
class OsInfo:
    id: str
    id_like: tuple[str, ...]
    version_id: str
    pretty_name: str
    package_family: str

    @property
    def supports_existing_package_actions(self) -> bool:
        return self.package_family == "apt"


@dataclass(frozen=True)
class SessionInfo:
    desktop: str
    desktop_session: str
    session_type: str


def _unquote(value: str) -> str:
    value = value.strip()
    if len(value) >= 2 and value[0] == value[-1] and value[0] in {'"', "'"}:
        return value[1:-1]
    return value


def parse_os_release(text: str) -> OsInfo:
    fields: dict[str, str] = {}
    for raw in text.splitlines():
        if "=" not in raw or raw.lstrip().startswith("#"):
            continue
        key, value = raw.split("=", 1)
        fields[key] = _unquote(value)

    distro_id = fields.get("ID", "linux")
    id_like = tuple(fields.get("ID_LIKE", "").split())
    family_tokens = {distro_id, *id_like}
    if family_tokens & {"debian", "ubuntu", "linuxmint"}:
        package_family = "apt"
    elif family_tokens & {"fedora", "rhel"}:
        package_family = "dnf"
    elif family_tokens & {"arch"}:
        package_family = "pacman"
    else:
        package_family = "unknown"

    return OsInfo(
        id=distro_id,
        id_like=id_like,
        version_id=fields.get("VERSION_ID", ""),
        pretty_name=fields.get("PRETTY_NAME", distro_id),
        package_family=package_family,
    )


def detect_session(env: dict[str, str] | None = None) -> SessionInfo:
    source = os.environ if env is None else env
    return SessionInfo(
        desktop=source.get("XDG_CURRENT_DESKTOP", "") or "unknown",
        desktop_session=source.get("DESKTOP_SESSION", "") or "unknown",
        session_type=source.get("XDG_SESSION_TYPE", "") or "unknown",
    )


def detect_package_managers() -> tuple[str, ...]:
    return tuple(name for name in ["apt-get", "dpkg-query", "dnf", "rpm", "pacman"] if shutil.which(name))


def detect_os(os_release_path: Path = Path("/etc/os-release")) -> OsInfo:
    text = os_release_path.read_text(encoding="utf-8", errors="replace") if os_release_path.exists() else ""
    return parse_os_release(text)
