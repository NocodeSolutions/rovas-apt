from __future__ import annotations

import os
import re
import subprocess
from pathlib import Path

from .status import detailed_status_lines, probe_system


SENSITIVE_KEY_RE = re.compile(r"(PASS|PASSWORD|TOKEN|SECRET|KEY)", re.IGNORECASE)


def redact(text: str) -> str:
    lines: list[str] = []
    for line in text.splitlines():
        if "=" in line:
            key, _value = line.split("=", 1)
            if SENSITIVE_KEY_RE.search(key):
                lines.append(f"{key}=<redacted>")
                continue
        lines.append(line)
    return "\n".join(lines)


def command_output(command: list[str]) -> str:
    result = subprocess.run(command, text=True, capture_output=True)
    output = result.stdout.strip() or result.stderr.strip()
    return output if output else "nincs adat"


def build_support_report() -> str:
    session_lines = [
        f"{key}={value}"
        for key, value in sorted(os.environ.items())
        if key.startswith("XDG_") or key in {"LANG", "LANGUAGE", "DESKTOP_SESSION"}
    ]
    return "\n".join(
        [
            "Rovas Tools Support Report",
            "",
            "[status]",
            detailed_status_lines(probe_system()),
            "",
            "[packages]",
            command_output([
                "dpkg-query",
                "-W",
                "rovas-common",
                "rovas-tools",
                "fonts-rovas",
                "rovas-keyboard",
                "rovas-locale-hu",
                "rovas-l10n-hu",
                "rovas-wallpapers",
                "rovas-browser-chromium",
            ]),
            "",
            "[session]",
            redact("\n".join(session_lines)),
            "",
        ]
    )


def build_safe_report(version: str, home: Path | None = None) -> str:
    home = home or Path.home()
    session_lines = [
        f"{key}={value}"
        for key, value in sorted(os.environ.items())
        if key.startswith("XDG_") or key in {"LANG", "LANGUAGE", "DESKTOP_SESSION"}
    ]
    try:
        status = detailed_status_lines(probe_system())
    except Exception as exc:
        status = f"status unavailable: {exc}"
    return "\n".join(
        [
            "Rovas Tools Safe Report",
            f"version={version}",
            "",
            "[status]",
            status,
            "",
            "[session]",
            redact("\n".join(session_lines)),
            "",
            "[paths]",
            f"home={home}",
            "",
        ]
    ).replace(str(home), "~")


def write_support_report(home: Path | None = None, content: str | None = None) -> Path:
    home = home or Path.home()
    path = home / "rovas-tools-report.txt"
    path.write_text(content if content is not None else build_support_report(), encoding="utf-8")
    return path
