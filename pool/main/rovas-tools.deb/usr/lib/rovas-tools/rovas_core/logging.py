from __future__ import annotations

from datetime import datetime
from pathlib import Path


LOG_NAME = "rovas-tools.log"


def log_path(home: Path | None = None) -> Path:
    return (home or Path.home()) / ".config" / "rovas-tools" / LOG_NAME


def redact_paths(message: str, home: Path | None = None) -> str:
    root = str(home or Path.home())
    redacted = message.replace(root, "~")
    return redacted.replace("\\", "/")


def append_log(home: Path | None, level: str, message: str) -> Path:
    path = log_path(home)
    path.parent.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with path.open("a", encoding="utf-8") as handle:
        handle.write(f"{timestamp}  {level:<5} {redact_paths(message, home)}\n")
    return path


def read_log(home: Path | None = None, *, max_lines: int = 200) -> str:
    path = log_path(home)
    if not path.exists():
        return "Nincs naplóbejegyzés."
    lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    return "\n".join(lines[-max_lines:]) if lines else "Nincs naplóbejegyzés."
